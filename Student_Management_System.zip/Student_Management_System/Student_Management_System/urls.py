"""
URL configuration for Student_Management_System project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from Student.views import *
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',Home),
    path('home',Home),
    path('students_list', students_list),
    path('addStudent',addStudent),
    path('studentDetails',studentDetails),
    path('teacher_list',teacher_list),
    path('course_list',course_list),
    path('addCourse',addCourse),
    path('Delete',Delete),
    path('Update_form',Update_form),
]