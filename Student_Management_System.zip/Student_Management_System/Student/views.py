from django.shortcuts import render,redirect
from django.http import HttpResponse
from Student.models import *
# Create your views here.
def Home(req):
    students_count=Students.objects.count()
    teacher_count=Teacher.objects.count()
    course_count=Courses.objects.count()
    return render(req, 'main.html',{'students_count':students_count,'teacher_count':teacher_count,'course_count':course_count})

def students_list(req):
    data=Students.objects.all()
    return render(req,'students_list.html',{'data':data})

def addStudent(req):
    if req.method == "POST":
        name = req.POST.get("name")
        roll_number = req.POST.get("roll_number")
        email = req.POST.get("email")
        dob = req.POST.get("dob")

        course_id = req.POST.get("course")
        course = Courses.objects.get(id=course_id)

        if clean_roll_number(roll_number):
            Students.objects.create(
                        name=name,
                        roll_number=roll_number,
                        email=email,
                        date_of_birth=dob,
                        course=course)
        else:
            return HttpResponse(f'404 Error found!!! \n Roll Number: {roll_number} Already Exist')
    courses = Courses.objects.all()
    return render(req, "Students_form.html",{'courses':courses})

def handle_roll_no_DB(roll_no):
    rn=Students.objects.values_list('roll_number',flat=True)
    data=list(rn)
    if roll_no in data:
        return True
    else:
        return False


def studentDetails(req):
    if req.method=='POST':
        roll_number_update=req.POST.get('roll_number')
        if handle_roll_no_DB(roll_number_update):
            data=Students.objects.get(roll_number=roll_number_update)
            return render(req,'display.html',{'data':data})
        else:
            if roll_number_update!='':
                return HttpResponse(f'Given Roll Number: {roll_number_update} Not in DataBase!')
            else:
                return redirect('students_list')
    return render(req,'students_details.html')

def clean_roll_number(roll_no):
    rn=Students.objects.values_list('roll_number',flat=True)
    data=list(rn)
    if roll_no not in data:
        return True
    else:
        return False

def teacher_list(req):
    data=Teacher.objects.all()
    return render(req,'teacher_list.html',{'data':data})

def course_list(req):
    data=Courses.objects.all()
    return render(req,'course_list.html',{'data':data})

def addCourse(req):
    if req.method=='POST':
        course_name=req.POST.get("course_name")
        course_code=req.POST.get("course_code")
        teacher_id = req.POST.get("teacher")
        teacher = Teacher.objects.get(id=teacher_id)
        Courses.objects.create(course_name=course_name,course_code=course_code,teacher=teacher)
        # return redirect('course_list')
    teachers=Teacher.objects.all()
    return render(req,'Course_form.html',{'teachers':teachers})
        
def Delete(req):
    id=req.GET.get('id')
    Students.objects.filter(roll_number=id).delete()
    return HttpResponse('data deleted! <a href="students_list">Back</a>')

def Update_form(req):
    id=req.GET.get('id')
    data=Students.objects.get(roll_number=id)
    courses = Courses.objects.all()
    if req.method=='POST':
        name = req.POST.get("name")
        roll_number = req.POST.get("roll_number")
        email = req.POST.get("email")
        dob = req.POST.get("dob")
        course_id = req.POST.get("course")
        course = Courses.objects.get(id=course_id)
        Students.objects.filter(roll_number=id).update(name=name,roll_number=roll_number,email=email,date_of_birth=dob,course=course)
        return HttpResponse('data Updated! <a href="students_list">Back</a>')
    return render(req,'Update_form.html',{'data':data,'courses':courses})