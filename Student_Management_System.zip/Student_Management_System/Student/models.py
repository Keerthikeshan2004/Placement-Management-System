from django.db import models

# Create your models here.
class Teacher(models.Model):
    teacher_name=models.CharField(max_length=100)
    subject_specialization=models.CharField(max_length=100)
    teacher_email=models.EmailField(unique=True)
    def __str__(self):
        return self.teacher_name

class Courses(models.Model):
    course_name=models.CharField(max_length=100)
    course_code=models.CharField(max_length=20,unique=True)
    teacher=models.ForeignKey(Teacher,on_delete=models.SET_NULL ,null=True)
    def __str__(self):
        return self.course_name

class Students(models.Model):
    name=models.CharField(max_length=100)
    roll_number=models.CharField(max_length=20,unique=True)
    email=models.EmailField(unique=True)
    date_of_birth=models.DateField()
    course=models.ForeignKey(Courses,on_delete=models.SET_NULL ,null=True) 