from django.contrib import admin
from Student.models import *

# Register your models here.

@admin.register(Students)
class Students_Admin(admin.ModelAdmin):
    list_display=['id','name','roll_number','email','date_of_birth','course']
    search_fields=['id','roll_number','email']
    list_filter=['course','date_of_birth']

@admin.register(Courses)
class Courses_Admin(admin.ModelAdmin):
    list_display=['id','course_name','course_code','teacher']
    search_fields=['id','course_code']
    list_filter=['course_name']

@admin.register(Teacher)
class Teacher_Admin(admin.ModelAdmin):
    list_display=['id','teacher_name','subject_specialization','teacher_email']
    search_fields=['id','teacher_name']
    list_filter=['subject_specialization']
